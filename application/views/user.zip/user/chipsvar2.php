<?php 
    include 'includes/header.php'; 
    $page = str_replace(' ', '', str_replace(')', '',str_replace('(', '', $gameDetail['game_name'])));
   
    if($gameDetail['id']=='6'){
        $sA = 'Select All Jodi';
    }else{
        $sA = 'Select All Patti';
    }
?>
    
    <div class="container container-custom">
        <div class="controlDv">
            <?php include 'includes/selectGames.php'; ?>
            <?php include 'includes/blankChips.php'; ?>
        </div>
        <div class="controlDv">
            <select name="game-var" aria-label="Game Selection" class="akdC" id="typeOfJodi" onchange="getGameTypePatti(this.value)">
                <!-- <option selected="">Choose a Game</option> -->
                <option value="All" selected="">Jodi All</option>
                <option value="EE">Even Even Jodi</option>
                <option value="OO">Odd Odd Jodi</option>
                <option value="OE">Odd Even Jodi</option>
                <option value="EO">Even Odd Jodi</option>
                    
            </select>
        </div>
        <p class="betNote"> NOTE : BET AMOUNT SHOULD GREATER OR EQUAL TO 10 </p>
        <div class="opnCLse">
            <form class="chk-form" action="#">
                <div class="chkL">
                    <input type="radio" id="test1" name="radio-group" checked>
                    <label for="test1">Open</label>
                </div>
                <div class="chkL">
                    <input type="radio" id="test2" name="radio-group">
                    <label for="test2">Close</label>
                </div>
            </form>
        </div>
        <div class="chipDV">
            <a class="chip coin" id="coin1" onclick="setCoin(1)">
                <img src="<?=base_url()?>assets/images/chips1.png" alt="">
            </a>
            <a class="chip coin" id="coin5" onclick="setCoin(5)">
                <img src="<?=base_url()?>assets/images/chips2.png" alt="">
            </a>
            <a class="chip coin" id="coin10" onclick="setCoin(10)">
                <img src="<?=base_url()?>assets/images/chips3.png" alt="">
            </a>
            <a class="chip coin" id="coin20" onclick="setCoin(20)">
                <img src="<?=base_url()?>assets/images/chips4.png" alt="">
            </a>
            <a class="chip coin" id="coin50" onclick="setCoin(50)">
                <img src="<?=base_url()?>assets/images/chips5.png" alt="">
            </a>
            <a class="chip coin" id="coin100" onclick="setCoin(100)">
                <img src="<?=base_url()?>assets/images/chips6.png" alt="">
            </a>
            <!-- <a class="chip coin" id="coin200" onclick="setCoin(200)">
                <img src="<?=base_url()?>assets/images/chips7.png" alt="">
            </a> -->
            <a class="chip coin" id="coin500" onclick="setCoin(500)">
                <img src="<?=base_url()?>assets/images/chips7.png" alt="">
            </a>
             
            <a class="chip coin" id="coin1000" onclick="setCoin(1000)">
                <img src="<?=base_url()?>assets/images/chips8.png" alt="">
            </a>
            <p class="betTxt">SELECT THE CHIPS AND BET</p>
        </div>
        <div class="totalBet">
            <p>Total Bet <span class="ramt"> <i class="fa fa-inr" aria-hidden="true"></i> 10</span></p>
        </div>
        <div class="clrBoth"></div>
        <span class="betPlaceTabel" id="getJodiPana">
            <table class="table">
                <tbody>
                    <div class="col-12 cplace-outer">
                        <div class="cplace-wrapper">
                        <?php
                        $a=array();
                        
                        for($i=0;$i<100;$i++){
                            array_push($a,$i);
                        }
                        foreach(array_chunk($a, 5) as $p) { 
                            echo '<tr>';
                            foreach($p as $i){
                                if($i<10)    {
                                    $i = '0'.$i;
                                }
                        ?>
                            <td>
                                <div class="cplace place-input-main" onclick="addCoinJodiAll(<?=$i?>)">
                                    <label class="inputNo"><?=str_pad($i, 2, '0', STR_PAD_LEFT)?></label>
                                    <br/>
                                    <div class="cplace-box btInput pos">
                                        <div id="<?=$page.$i?>Akda-wrapper" class="text-center"></div>
                                    </div>
                                </div>          
                            </td>
                        <?php
                            }
                            echo '</tr>';
                        }
                        ?> 
                        </div>
                    </div>
                </tbody>
            </table>
        </span>
        <?php include 'includes/resultSection.php'; ?>
    </div>
           
    <?php 
          include 'includes/footer.php'; 
    ?>
     

    <script>
       $(document).ready(function() {
        var viewWidth;
        var viewHeight;

        if(window.innerWidth !== undefined && window.innerHeight !== undefined) { 
            viewWidth = window.innerWidth;
            viewHeight = window.innerHeight;
        } else {  
            viewWidth = document.documentElement.clientWidth;
            viewHeight = document.documentElement.clientHeight;
        }

    }); 
    </script>



     <!-- <script type="text/javascript">
    $(document).ready(function() {
        if(<?=$gameDetail['id']?>==2){
            var ty = 'DP';
        }else if(<?=$gameDetail['id']?>==1){
            var ty = 'SP';
        }
        var data = checkPannaType('SP/DP/TP',ty);
        $(data).each(function(i) {
            dome='<div class="cplace" onclick="addCoinSingleDigit('+data[i]+',\'<?=$page?>\')"><span>'+data[i]+'</span><div class="cplace-box"><div id="<?=$page?>'+data[i]+'Akda-wrapper" class="text-center"></div></div></div>';
            $('#dome').append(dome);
        });


        // <div class="cplace" onclick="addCoinSingleDigit(<?=$i?>, '<?=$page?>')"><span><?=$i?></span>
        //                 <div class="cplace-box" >
        //                     <div id="<?=$page.$i?>Akda-wrapper" class="text-center"></div>
        //                 </div>
        //             </div>   
    }); -->
<!-- </script> -->