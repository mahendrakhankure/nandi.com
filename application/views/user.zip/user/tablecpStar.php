<?php 
    include 'includes/header.php'; 
?>
    <div class="container container-custom">
        <div class="controlDv">
            <div class="batt-name select-wrapper">
                <?php include 'includes/selectGamesStar.php'; ?>
            </div>  
            <div class="select-date select-wrapper dark">
                <select class="akdC" name="batt-date" id="date" onchange="checkOpenCloseRegular('<?=$status[0]['game_type1']?>','<?=$status[0]['game_type2']?>')">
                        <option value="<?=$status[0]['date']?>"><?=$status[0]['date']?></option>
                        <option value="<?=$status[1]['date']?>"><?=$status[1]['date']?></option>
                        <option value="<?=$status[2]['date']?>"><?=$status[2]['date']?></option>
                    </select>
            </div> 
        </div>
        <div class="container" style="display:none;">
            <div class="rows">
                <div class="col-md-8 col-sm-10 col-xs-10 offset-md-2 offset-sm-1  game-type-wrapper">
                    <div class="game-type">
                        <input type="hidden" name="starTime" value="<?=$marketTime['time']?>" id="starTime" style="display:none;">
                        <input type="hidden" name="time" value="<?=$param['time']?>" id="time" style="display:none;">
                        <input type="radio" id="Jodi" name="gt-radio" value="Jodi" style="display:none;" checked>
                    </div>
                    
                </div>
            </div>
        </div>
        <p class="betNote"> NOTE : BET AMOUNT SHOULD GREATER OR EQUAL TO 10 </p>
        
        <div class="opnCLse">
            <form class="chk-form Col-3-check" action="#">
                <div class="chkL">
                    <input class="check1" name="check" type="checkbox" value="SP" id="check1">
                    <label for="test11">SP</label>
                </div>
                <div class="chkL">
                    <input class="check2" name="check" type="checkbox" value="DP" id="check2">
                    <label for="test22">DP</label>
                </div>
                <div class="chkL">
                    <input class="check3" name="check" type="checkbox" value="TP" id="check3">
                    <label for="test33">TP</label>
                </div>
            </form>
        </div>
        
          <div class="controlDv akdDV">
              <div class="akdCOuter">
                  <label>Left</label>
                  <input type="number" class="form-control" id="left" onkeypress="return isNumber(event)" maxlength="1" oninput="maxLengthCheck(this)">
              </div>     
             <div class="akdCOuter">
                  <label>Middle</label>
                  <input type="number" class="form-control" id="middle" onkeypress="return isNumber(event)" maxlength="1" oninput="maxLengthCheck(this)">
              </div>
              <div class="akdCOuter">
                  <label>Right</label>
                  <input type="number" class="form-control" id="right" onkeypress="return isNumber(event)" maxlength="1" oninput="maxLengthCheck(this)">       
              </div>
        </div>
       <div class="controlDv akdC">
            <input type="number" name="ent-amount" id="ent-amount" placeholder="Enter Amount" onkeypress="return isNumber(event)" maxlength="4" oninput="maxLengthCheck(this)">                  
        </div> 
        <div class="controlDv akdC">
         <button class="right-al" onclick="addBets('choicePana')">+ Add More</button>
        </div>
        
        <div class="totalBet">
            <p>Total Bet <span class="ramt"> <i class="fa fa-inr" aria-hidden="true"></i> <span id= "totalAmount">0.0</span></span></p>
        </div>
        <div class="clrBoth"></div>
        <div class="betPlaceTabelComb">
        <div class="betPlaceTabel pana-Table">
            <table class="table">
                <thead>
                    <tr>
                        <th>Pana</th>
                        <th>Points</th>
                        <th>Game Patti</th>
                        <th>Delete</th>
                    </tr> 
                </thead>
                <tbody>
                    <tr>

                    </tr>
                </tbody>
            </table>
        </div>
            
        </div>    
        <div class="totalNo">
            <span>Total no of bid:<span id = "totalBet">0</span></span>
            <span>Total amount:<span id= "totalAmount">0.0</span></span>
        </div>
        <div class="betResSection">
            <a href="javascript:void(0)" onclick="resetAll()" class="imgBtn"><img src="<?=base_url()?>assets/images/cross.png"> Reset Bet</a>
            <div class="clrBoth"></div>
            <a href="javascript:void(0)" onclick="placeBetStar(<?=$param['bazar_id']?>,<?=$param['game_id']?>)" class="plceBet">Place Bet</a>
            <span class="separate"></span>
            <h5 class="lrest">Last Result</h5>
            <p class="lresDate"><?=date('d-m-Y',strtotime($gameResult[0]['result_date']))?> <span><?=$gameResult[0]['open']?>-<?=$gameResult[0]['jodi']?>-<?=$gameResult[0]['close']?></span></p>
            <p class="lresDate"><?=date('d-m-Y',strtotime($gameResult[1]['result_date']))?> <span><?=$gameResult[1]['open']?>-<?=$gameResult[1]['jodi']?>-<?=$gameResult[1]['close']?></span></p>
            <p class="lresDate"><?=date('d-m-Y',strtotime($gameResult[2]['result_date']))?> <span><?=$gameResult[2]['open']?>-<?=$gameResult[2]['jodi']?>-<?=$gameResult[2]['close']?></span></p>
            <p class="lresDate"><?=date('d-m-Y',strtotime($gameResult[3]['result_date']))?> <span><?=$gameResult[3]['open']?>-<?=$gameResult[3]['jodi']?>-<?=$gameResult[3]['close']?></span></p>
        </div>  
    </div>

<?php 
    include 'includes/footer.php'; 
?>