<?php 
    include 'includes/header.php'; 
    $page = str_replace(' ', '', str_replace(')', '',str_replace('(', '', $gameDetail['game_name'])));
?>
        <div class="container container-custom">
        <div class="controlDv">
            <div class="batt-name select-wrapper">
                <?php include 'includes/selectGames.php'; ?>
            </div>  
            <div class="select-date select-wrapper dark">
                <?php include 'includes/blankChips.php'; ?>
            </div> 
        </div>
        <span class="blink_me" id="blink_me"><?= $status[0]['game_type1'] == 'NULL' ? 'Open Result Is Already Decleared':''; ?></span>
        <p class="betNote"> NOTE : BET AMOUNT SHOULD GREATER OR EQUAL TO 10 </p>
        
        
        <div class="controlDv akdDV">
            <div class="bett-var-form  ">
                <h3 class="bettin text-center heading" id = "game-name"><?=$gameDetail['game_name']?></h3>
                <div class="var-type-sf">
                    <input type="number" name="ent-digit" id="ent-digit" placeholder="Enter Digit" required minlength="1" maxlength="1" onkeypress="return isNumber(event)" oninput="maxLengthCheck(this)">
                    <input type="number" name="ent-amount" id="ent-amount" placeholder="Enter Amount" required maxlength="4" onkeypress="return isNumber(event)" oninput="maxLengthCheck(this)">
                </div>
                <div class="var-type-btn">
                    <button class="sl-all" onclick="addBetsJodiCount('<?=$page?>')">+ Add More</button>
                </div>
            </div>
        </div>
        <div class="totalBet">
            <p>Total Bet <span class="ramt"> <i class="fa fa-inr" aria-hidden="true"></i> <span id= "totalAmount">0.0</span></span></p>
        </div>
        <div class="clrBoth"></div>
        <div class="betPlaceTabelComb">
        <div class="betPlaceTabel pana-Table">
            <table class="table">
                <thead>
                    <tr>
                        <th>Jodi</th>
                        <th>Points</th>
                        <th>Delete</th>
                    </tr> 
                </thead>
                <tbody>
                    <tr>

                    </tr>
                </tbody>
            </table>
        </div>
            
        </div>    
        <div class="totalNo">
            <span>Total no of bid:<span id = "totalBet">0</span></span>
            <span>Total amount:<span id= "totalAmount">0.0</span></span>
        </div>
        <?php include 'includes/resultSection.php'; ?> 
    </div>
         
        
<?php 
    include 'includes/footer.php'; 
?>
 