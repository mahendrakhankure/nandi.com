<?php 
    include 'includes/header.php'; 
    if($gameDetail['id']==12){
        $gameDetail['game_name']=substr($gameDetail['game_name'],0,-3);
    }
    $page = str_replace(' ', '', str_replace(')', '',str_replace('(', '', $gameDetail['game_name'])));
    if($gameDetail['id']==12 || $gameDetail['id']==23 || $gameDetail['id']==35){
        $page="twoDigitPanel";
    }
?>
       
       <div class="container container-custom">
        <div class="controlDv">
            <div class="batt-name select-wrapper">
                <?php include 'includes/selectGamesStar.php'; ?>
            </div>  
            <div class="select-date select-wrapper dark">
                <select class="akdC" name="batt-date" id="date" onchange="checkOpenCloseRegular('<?=$status[0]['game_type1']?>','<?=$status[0]['game_type2']?>')">
                        <option value="<?=$status[0]['date']?>"><?=$status[0]['date']?></option>
                        <option value="<?=$status[1]['date']?>"><?=$status[1]['date']?></option>
                        <option value="<?=$status[2]['date']?>"><?=$status[2]['date']?></option>
                    </select>
            </div> 
        </div>
        <input type="radio" id="open" name="gt-radio" value="open" checked style="display:none;">
        
        <p class="betNote"> NOTE : BET AMOUNT SHOULD GREATER OR EQUAL TO 5 </p>
        
        <div class="container">
            <div class="rows">
                <div class="col-md-8 col-sm-12 offset-md-2">
                    <div class="bett-var-form">
                        <h3 class="bettin text-center heading" id = "game-name"><?=$gameDetail['game_name']?></h3>
                        <div class="var-type-sf">
                            <input type="number" name="ent-digit" id="ent-digit" placeholder="Enter Digit" required minlength="4" maxlength="10" onkeyup="return SPDPDigit('<?=$page?>', this.value, event)" onkeypress="return isNumber(event)" oninput="maxLengthCheck(this)">
                            <input type="number" name="ent-amount" id="ent-amount" placeholder="Enter Amount" required maxlength="4"   onkeypress="return isNumber(event)" oninput="maxLengthCheck(this)">
                        </div>
                        <div class="var-type-btn">
                            <button onclick="addBets('<?=$page?>')">+ Add More</button>
                        </div>
                    </div>
            
                </div>
            </div>
        </div>
        
        <div class="totalBet">
            <p>Total Bet <span class="ramt"> <i class="fa fa-inr" aria-hidden="true"></i> <span id= "totalAmount">0.0</span></span></p>
        </div>
        <div class="clrBoth"></div>
        <div class="betPlaceTabelComb">
        <div class="betPlaceTabel pana-Table">
            <table class="table text-center">
                <thead>
                    <tr>
                    <th>Pana</th>
                    <th>Points</th>
                    <th>Delete</th>
                    </tr> 
                </thead>
                <tbody>
                        <tr>

                        </tr>
                </tbody>
            </table>
        </div>
            
        </div>    
        <div class="totalNo">
            <span>Total no of bid:<span id = "totalBet">0</span></span>
            <span>Total amount:<span id= "totalAmount">0.0</span></span>
        </div>
        <div class="betResSection">
            <a href="javascript:void(0)" onclick="resetAll()" class="imgBtn"><img src="<?=base_url()?>assets/images/cross.png"> Reset Bet</a>
            <div class="clrBoth"></div>
            <a href="javascript:void(0)" onclick="placeBetStar(<?=$param['bazar_id']?>,<?=$param['game_id']?>)" class="plceBet">Place Bet</a>
            <span class="separate"></span>
            <h5 class="lrest">Last Result</h5>
            <p class="lresDate"><?=date('d-m-Y',strtotime($gameResult[0]['result_date']))?> <span><?=$gameResult[0]['open']?>-<?=$gameResult[0]['jodi']?>-<?=$gameResult[0]['close']?></span></p>
            <p class="lresDate"><?=date('d-m-Y',strtotime($gameResult[1]['result_date']))?> <span><?=$gameResult[1]['open']?>-<?=$gameResult[1]['jodi']?>-<?=$gameResult[1]['close']?></span></p>
            <p class="lresDate"><?=date('d-m-Y',strtotime($gameResult[2]['result_date']))?> <span><?=$gameResult[2]['open']?>-<?=$gameResult[2]['jodi']?>-<?=$gameResult[2]['close']?></span></p>
            <p class="lresDate"><?=date('d-m-Y',strtotime($gameResult[3]['result_date']))?> <span><?=$gameResult[3]['open']?>-<?=$gameResult[3]['jodi']?>-<?=$gameResult[3]['close']?></span></p>
        </div>  
    </div>
         
     
<?php 
    include 'includes/footer.php'; 
?>
 
 