<html>
          	   <head xmlns="http://www.w3.org/1999/xhtml" debug="true">
                   <meta name="viewport" content="width=device-width, initial-scale=1.0">
                  <!--<meta name="viewport" content="target-densitydpi=device-dpi" />-->
                   <script type="text/javascript">
                     function init()
                     {
                        AndroidFunction.doneClick();
                     }
                   </script>
                   <style>
                       *{
                           box-sizing: border-box
                       }
                   </style>
                           
          	   </head>
          	<body>
        	<div style="background-color: #f8191a;width: 100%; overflow: hidden;margin: 0 auto;box-sizing: border-box;padding: 40px; margin-top: 40px; height: 100%;padding-top: 0;margin-top: 0">
              <div style="background-color: white;margin-top: 40%;padding: 80px 30px 80px 30px;text-align: center;position: relative;"> 
                <div>  
                <h1 style="text-transform: uppercase;color: #55585b;font-size: 28px;font-weight: 500;margin-bottom: 5px;">OUR APP IS IN MAINTANANCE</h1> 
             </div>
              </div>
                <div style="text-align:center;    margin-top: 30px;">
                <button style="background-color: #fff; border: none; color: #f8191a; text-align: center; text-decoration: none; display: inline-block; font-size: 16px; margin: 4px 2px; cursor: pointer; padding: 14px 40px; border-radius: 10px;" onclick="javascript:return init();">Done</button>
            </div>
            </div>
            
            </body>
        </html>