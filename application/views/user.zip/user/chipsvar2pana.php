
<?php 
    include 'includes/header.php'; 
    $page = str_replace(' ', '', str_replace(')', '',str_replace('(', '', $gameDetail['game_name'])));  
?>
     
        <div class="container container-custom">
        <div class="controlDv">
            <?php include 'includes/selectGames.php'; ?>
            <?php include 'includes/blankChips.php'; ?>
        </div>
        <p class="betNote"> NOTE : BET AMOUNT SHOULD GREATER OR EQUAL TO <?=$param['type_id']==5?'10':'5';?> </p>

        <div class="col-12 myselect-outer-wrapper">  
            <div class="select-jodi  select-wrapper">
                <select name="game-var" aria-label="Game Selection" id="typeOfdata"    onchange="getGameTypePanaNew(this.value)">
                    <option value="EEE" selected="">Even Even Even</option>
                    <option value="EEO">Even Even Odd</option>
                    <option value="EOE">Even Odd Even</option>
                    <option value="EOO">Even Odd Odd</option>
                    <option value="OEE">Odd Even Even</option>
                    <option value="OEO">Odd Even Odd</option>
                    <option value="OOE">Odd Odd Even</option>
                    <option value="OOO">Odd Odd Odd</option>
                        
                </select>
            </div>  
        </div>

        <div class="game-type-wrapper">
            <div class="opnCLse" id="game-open-close">   
                <form class="chk-form"> 
                    <div class="gt-open chkL">
                        <input type="radio" id="open" name="gt-radio" value="open" <?= $status[0]['game_type1'] == 'NULL' ? 'disabled':''; ?>>
                        <label for="open">Open</label>
                    </div>
                    <div class="gt-close chkL">
                        <input type="radio" id="close" name="gt-radio" value="close" <?= $status[0]['game_type2'] == 'NULL' ? 'disabled':''; ?>>
                        <label for="close">Close</label>
                    </div>
                </form>         
            </div>
            <span class="blink_me" id="blink_me"><?= $status[0]['game_type1'] == 'NULL' ? 'Open Result Is Already Decleared':''; ?></span>
        </div>
        <div class="chipDV">
            <a class="chip coin" id="coin1" onclick="setCoin(1)">
                <img src="<?=base_url()?>assets/images/chips1.png" alt="">
            </a>
            <a class="chip coin" id="coin5" onclick="setCoin(5)">
                <img src="<?=base_url()?>assets/images/chips2.png" alt="">
            </a>
            <a class="chip coin" id="coin10" onclick="setCoin(10)">
                <img src="<?=base_url()?>assets/images/chips3.png" alt="">
            </a>
            <a class="chip coin" id="coin20" onclick="setCoin(20)">
                <img src="<?=base_url()?>assets/images/chips4.png" alt="">
            </a>
            <a class="chip coin" id="coin50" onclick="setCoin(50)">
                <img src="<?=base_url()?>assets/images/chips5.png" alt="">
            </a>
            <a class="chip coin" id="coin100" onclick="setCoin(100)">
                <img src="<?=base_url()?>assets/images/chips6.png" alt="">
            </a>
            <!-- <a class="chip coin" id="coin200" onclick="setCoin(200)">
                <img src="<?=base_url()?>assets/images/chips7.png" alt="">
            </a> -->
            <a class="chip coin" id="coin500" onclick="setCoin(500)">
                <img src="<?=base_url()?>assets/images/chips7.png" alt="">
            </a>
             
            <a class="chip coin" id="coin1000" onclick="setCoin(1000)">
                <img src="<?=base_url()?>assets/images/chips8.png" alt="">
            </a>
            <p class="betTxt">SELECT THE CHIPS AND BET</p>
        </div>
        <div class="totalBet">
            <p>Total Bet <span class="ramt"> <i class="fa fa-inr" aria-hidden="true"></i><span id="totalAmount">0</span></span></p>
        </div>
        <div class="clrBoth"></div>
        <div class="betPlaceTabelComb">
            <span class="betPlaceTabel" id="getEvenOddPana">
           
            </span>
        </div>
        <?php include 'includes/resultSection.php'; ?> 
    </div>
         
        
    <?php 
          include 'includes/footer.php'; 
    ?>
     
     <script>
        $(document).ready(function(){
            getGameTypePanaNew('EEE');
        });
    </script>

        <script>
       $(document).ready(function() {
        var viewWidth;
        var viewHeight;

        if(window.innerWidth !== undefined && window.innerHeight !== undefined) { 
            viewWidth = window.innerWidth;
            viewHeight = window.innerHeight;
        } else {  
            viewWidth = document.documentElement.clientWidth;
            viewHeight = document.documentElement.clientHeight;
        }
        if(parseInt(viewWidth) <= 340) {
            cplaceHeight = viewHeight-360-44;
            $(".cplace-outer").height(cplaceHeight);
        }
        if(parseInt(viewWidth) > 340 && parseInt(viewWidth) <= 460) {
            cplaceHeight = viewHeight-370-44;
            $(".cplace-outer").height(cplaceHeight);
        }else if(parseInt(viewWidth) > 460 && parseInt(viewWidth) < 768)   {
            cplaceHeight = viewHeight-394-44;
            $(".cplace-outer").height(cplaceHeight);
        }else if(parseInt(viewWidth) >= 768) {
            cplaceHeight = viewHeight-359-44;
            $(".cplace-outer").height(cplaceHeight);
        }

    }); 
    </script> 