<?php 
    include 'includes/header.php'; 
    $page = str_replace(' ', '', str_replace(')', '',str_replace('(', '', $gameDetail['game_name'])));  
?>
    <style type="text/css">
        /**
         * Box model adjustments
         * `border-box`... ALL THE THINGS - http://cbrac.co/RQrDL5
         */

        *,
        *:before,
        *:after {
          -webkit-box-sizing: border-box;
          -moz-box-sizing: border-box;
          box-sizing: border-box;
        }

        /**
         * 1. Force a vertical scrollbar - http://cbrac.co/163MspB
         * NOTE: Use `text-rendering` with caution - http://cbrac.co/SJt8p1
         * NOTE: Avoid the webkit anti-aliasing trap - http://cbrac.co/TAdhbH
         * NOTE: IE for Windows Phone 8 ignores `-ms-text-size-adjust` if the
         *       viewport <meta> tag is used - http://cbrac.co/1cFrAvl
         */

        html {
          font-size: 100%;
          overflow-y: scroll; /* 1 */
          min-height: 100%;
        }

        /**
         * 1. Inherits percentage declared on above <html> as base `font-size`
         * 2. Unitless `line-height`, which acts as multiple of base `font-size`
         */

        body {
          font-family: "Helvetica Neue", Arial, sans-serif;
          font-size: 1em;   /* 1 */
          line-height: 1.5; /* 2 */
          color: #444;
        }

        /* Page wrapper */
        .wrapper {
          width: 90%;
          max-width: 800px;
          margin: 4em auto;
          text-align: center;
        }

        /* Icons */
        .icon {
          display: inline-block;
          width: 16px;
          height: 16px;
          vertical-align: middle;
          fill: currentcolor;
        }

        /* Headings */
        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
          color: #222;
          font-weight: 700;
          font-family: inherit;
          line-height: 1.333;
          text-rendering: optimizeLegibility;
        }

        /**
         * Modals ($modals)
         */

        /* 1. Ensure this sits above everything when visible */
        .modal {
            position: absolute;
            z-index: 10000; /* 1 */
            top: 0;
            left: 0;
            visibility: hidden;
            width: 100%;
            height: 100%;
        }

        .modal.is-visible {
            visibility: visible;
        }

        .modal-overlay {
          position: fixed;
          z-index: 10;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: hsla(0, 0%, 0%, 0.5);
          visibility: hidden;
          opacity: 0;
          transition: visibility 0s linear 0.3s, opacity 0.3s;
        }

        .modal.is-visible .modal-overlay {
          opacity: 1;
          visibility: visible;
          transition-delay: 0s;
        }

        .modal-wrapper {
          position: absolute;
          z-index: 9999;
          top: 6em;
          left: 50%;
          width: 32em;
          margin-left: -16em;
          background-color: #fff;
          box-shadow: 0 0 1.5em hsla(0, 0%, 0%, 0.35);
        }

        .modal-transition {
          transition: all 0.3s 0.12s;
          transform: translateY(-10%);
          opacity: 0;
        }

        .modal.is-visible .modal-transition {
          transform: translateY(0);
          opacity: 1;
        }

        .modal-header,
        .modal-content {
          padding: 1em;
        }

        .modal-header {
          position: relative;
          background-color: #fff;
          box-shadow: 0 1px 2px hsla(0, 0%, 0%, 0.06);
          border-bottom: 1px solid #e8e8e8;
        }

        .modal-close {
          position: absolute;
          top: 0;
          right: 0;
          padding: 1em;
          color: #aaa;
          background: none;
          border: 0;
        }

        .modal-close:hover {
          color: #777;
        }

        .modal-heading {
          font-size: 1.125em;
          margin: 0;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }

        .modal-content > *:first-child {
          margin-top: 0;
        }

        .modal-content > *:last-child {
          margin-bottom: 0;
        }

        .mktitem1   {
            position: relative;

        }
        .mktitem1 .tv-icon-wrapper, .mktitem1 .holi-icon-wrapper  {
            position: absolute;
            top : 10%;
        }
        .mktitem1 .tv-icon-wrapper p, .holi-icon-wrapper p {
            font-size : 9px;
            margin-top : 5px;
        }
        .mktitem1 .tv-icon-wrapper  {
            left : 5%;
        } 
        .mktitem1 .holi-icon-wrapper    {
            right:5%;
        }
        .mktitem1 .bazar-icon   {
            width: 30px;
        }
    </style>
  
        <!-- Market List -->
        <div class="container" >
            <div class="row sec-margin mktlist">

            <?php 
                $i=0;
                foreach($marketList as $list){
                   
            ?>
                <div class="col-lg-4 col-md-6 col-sm-12">
                <a href="<?php echo base_url();?>9a27a7e97c16a7b3ac6382d21205357f/<?=$list['bazar_id']?>/<?=$list['result']?><?=$tUrl?>">
                  <div class="mktitem-wrapper">
                    <div class="dark mktitem1 text-center regularmkt">
                            <?php
                                if($list['icon_status']=='1'){
                            ?>
                                <div class="tv-icon-wrapper">
                                    <img src="<?=base_url().$list['icon']?>" class="tv-icon bazar-icon" id="icn">
                                    <p id="icnText" class="l-txt"><?=$list['text']?></p>
                                </div>
                            <?php } ?>
                            <?php
                                if($list['icon_status1']=='1'){
                            ?>
                                <div class="holi-icon-wrapper">
                                    <img src="<?=base_url().$list['icon1']?>" class="holi-icon bazar-icon" id="icn1">
                                    <p id="icnText1" class="r-txt"><?=$list['text1']?></p>
                                </div>
                            <?php } ?>
                            <div class="mkttopchip"></div>
                            <div class="mktglowchip"></div>
                            <h2 class="mktitem-name"><?=$list['bazar_name'];?></h2>
                            <h3 class="mktitem-result"> <?php 
                                if($list['result']!="--"){
                                    echo $list['result'];
                                }else{
                                    echo '***-**-***';
                                }
                            ?></h3>
                            <p class="mktitem-day"><?php 
                                if(strtotime($list['close_time'])<=time()){
                                    echo 'Running for tomorrow';
                                }else{
                                    echo '<span class="blink">Running for today</span>';
                                }
                            ?></p>
                            <div class="row timer-row">
                                <div class= "mktitem-time-wrapper col-5 col-xs-5">
                                    <p><?=date('h:i A',strtotime($list['open_time']))?></p>
                                    <p style="padding-top: 5px;">Open</p>
                                    <!-- <div class="mktitem-time clockdiv" data-date="<?=date('Y-m-d H:i:s',strtotime($list['open_time']))?>"> -->
                                    <div class="mktitem-time clockdiv" data-date="<?=date($list['oD'][0].' H:i:s',strtotime($list['open_time']))?>">
                                        <div style="display:none;">
                                            <span class="days"></span>
                                        </div>
                                        <div class="">
                                            <span class="hours"></span>H
                                        </div>
                                        <div class="">
                                            <span class="minutes"></span>M
                                        </div>
                                        <div class="">
                                            <span class="seconds"></span>S
                                        </div>
                                    </div>
                                </div>
                                <div class="col-2 col-xs-2"><img src="<?php echo base_url();?>assets/images/watch1.png" width="30" height="30"></div>
                                <div class= "mktitem-time-wrapper col-5 col-xs-5" >
                                  <p><?=date('h:i A',strtotime($list['close_time']))?></p>
                                   <p style="padding-top: 5px;">Close</p>
                                    <!-- <div class="mktitem-time clockdiv" data-date="<?=date('Y-m-d H:i:s',strtotime($list['close_time']))?>"> -->
                                    <div class="mktitem-time clockdiv" data-date="<?=date($list['cD'][0].' H:i:s',strtotime($list['close_time']))?>">
                                        <div style="display:none;">
                                            <span class="days"></span>
                                        </div>
                                        <div class="">
                                            <span class="hours"></span>H
                                        </div>
                                        <div class="">
                                            <span class="minutes"></span>M
                                        </div>
                                        <div class="">
                                            <span class="seconds"></span>S
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mktbottomchip"></div>
                    </div>
                  </div>
                </a>    
                </div>
                <?php $i++; } ?>
            </div>
        </div>
         
    <div class="modal">
        <div class="modal-overlay modal-toggle"></div>
        <div class="modal-wrapper modal-transition">
          <div class="modal-header">
            <button class="modal-close modal-toggle"><svg class="icon-close icon" viewBox="0 0 32 32"><use xlink:href="#icon-close"></use></svg></button>
            <h2 class="modal-heading">This is a modal</h2>
          </div>
          
          <div class="modal-body">
            <div class="modal-content">
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Impedit eum delectus, libero, accusantium dolores inventore obcaecati placeat cum sapiente vel laboriosam similique totam id ducimus aperiam, ratione fuga blanditiis maiores.</p>
              <button class="modal-toggle">Update</button>
            </div>
          </div>
        </div>
    </div>
    <?php 
          include 'includes/footer.php'; 
    ?>
<script type="text/javascript">
    $(document).ready(function() {
      const queryString = window.location.search;
      const urlParams = new URLSearchParams(queryString);
      const product = urlParams.get('app')
        if(product=='FB'){
            $('.mktitem-time-wrapper p').css({'color':'#fff'});
        }  
    });
</script>