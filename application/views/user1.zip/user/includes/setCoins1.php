<div class="col-12 mychips-wrapper">
                <h4 class="text-center" >Select the chips and Bet</h4>
                <div class="mychips">
                    <div class="chip-option-wrapper coin" id="coin1" onclick="setCoin(1)">
                        <div class="chip">
                            <img src="<?=base_url()?>assets/images/chips1.png" alt="">
                        </div>
                    </div>
                    <div class="chip-option-wrapper coin"  id="coin5" onclick="setCoin(5)">
                        <div class="chip">
                            <img src="<?=base_url()?>assets/images/chips2.png" alt="">
                        </div>
                    </div>
                    <div class="chip-option-wrapper coin"  id="coin10" onclick="setCoin(10)">
                        <div class="chip">    
                            <img src="<?=base_url()?>assets/images/chips3.png" alt="">
                        </div>
                    </div>
                    <div class="chip-option-wrapper coin"  id="coin20" onclick="setCoin(20)">
                        <div class="chip">
                            <img src="<?=base_url()?>assets/images/chips4.png" alt="">
                        </div>
                    </div>
                    <div class="chip-option-wrapper coin"  id="coin50" onclick="setCoin(50)">
                        <div class="chip">
                            <img src="<?=base_url()?>assets/images/chips5.png" alt="">
                        </div>
                    </div>
                    <div class="chip-option-wrapper coin"  id="coin100" onclick="setCoin(100)">
                        <div class="chip">
                            <img src="<?=base_url()?>assets/images/chips6.png" alt="">
                        </div>
                    </div>
                    <div class="chip-option-wrapper coin"  id="coin200" onclick="setCoin(200)">
                        <div class="chip">
                            <img src="<?=base_url()?>assets/images/chips7.png" alt="">
                        </div>
                    </div>
                    <div class="chip-option-wrapper coin"  id="coin500" onclick="setCoin(500)">
                        <div class="chip">
                            <img src="<?=base_url()?>assets/images/chips8.png" alt="">
                        </div>
                    </div>
                    <div class="chip-option-wrapper coin"  id="coin1000" onclick="setCoin(1000)">
                        <div class="chip">
                            <img src="<?=base_url()?>assets/images/chips9.png" alt="">
                        </div>
                    </div>
                </div>
            </div>