<div class="col-12 game-notes">
    <h3 >NOTE : Minimum <?=$minBet;?> & Maximum <?=$maxBet;?> Bet Limit</h3>
</div>