<div id="betL" style="display:none;">
    <div id="loaderBet"></div>
    <p id="message-1"></p>
</div>