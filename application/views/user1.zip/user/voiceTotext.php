<html></html>
<head>
	<title>Speech to text Converter</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body{
			font-family: Open Sans;
		}
		#result{
			height: 200px;
			border: 1px solid #ccc;
			padding: 10px;
			box-shadow: 0 0 10px 0 #bbb;
			margin-bottom: 30px;
			font-size: 14px;
			line-height: 25px;
		}
		button{
			font-size: 20px;
			position: absolute;
			top: 240px;
			left: 50%;
		}
    </style>
</head>
<body>
	<h3 align="center">Speech to text converter JavaScript</h3>
	<div id="result"></div>
	<button onclick="startConverting();"><i class="fa fa-microphone btn btn-danger" aria-hidden="true"></i></button>
</body>
<script>
    
		var result = document.getElementById('result');
        function startConverting () {
        if('webkitSpeechRecognition' in window) {
            var speechRecognizer = new webkitSpeechRecognition();
            speechRecognizer.continuous = true;
            speechRecognizer.interimResults = true;
            speechRecognizer.lang = 'en-US';
            speechRecognizer.start();

            var finalTranscripts = '';

            speechRecognizer.onresult = function(event) {
                var interimTranscripts = '';
                for(var i = event.resultIndex; i < event.results.length; i++){
                    console.log(i)
                    var transcript = event.results[i][0].transcript;
                    transcript.replace("\n", "<br>");
                    if(event.results[i].isFinal) {
                        finalTranscripts += transcript;
                    }else{
                        interimTranscripts += transcript;
                    }
                }
                result.innerHTML = finalTranscripts + '<span style="color: #999">' + interimTranscripts + '</span>';
            };
            speechRecognizer.onerror = function (event) {

            };
        }else {
            result.innerHTML = 'Your browser is not supported. Please download Google chrome or Update your Google chrome!!';
        }	
  }
</script>
</html>